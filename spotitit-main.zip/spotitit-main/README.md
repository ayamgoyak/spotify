# Preview
![IMG_20230616-154526942!](IMG_20230616-154526942.jpg)


# Cara penggunaan
Termux - Android (recommended version 0.117-Last)

https://apkcombo.com/id/termux/com.termux/old-versions/0.119.1/

1. pkg upgrade && update
2. pkg install git
3. pkg install php
4. termux-setup-storage
5. git clone https://github.com/mza-xxdv/spotitit.git
6. cd spotitit
7. php index.php

